#pragma once

// ===== I2C común =====
#define I2C_SDA 21
#define I2C_SCL 22

// ===== DS18B20 =====
#define DS18B20_PIN 4
#define TEMP_OFFSET -0.72f

// ===== ADS1115 =====
#define ADS_ADDR 0x48
#define PH_CHANNEL 0
#define EC_CHANNEL 1

// ===== HC-SR04 =====
#define HCSR04_TRIG 23
#define HCSR04_ECHO 35
#define ECHO_TIMEOUT_US 30000UL

// ===== Anillo LED =====
#define LED_RING_PIN   25
#define LED_RING_COUNT 8
