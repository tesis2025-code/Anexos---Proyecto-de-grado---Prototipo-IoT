#pragma once
#include <Arduino.h>

struct TempReading {
  float c = NAN;
  bool ok = false;
};

struct PHReading {
  float ph = NAN;
  float volts = NAN;
  bool ok = false;
};

struct ECReading {
  float ec_mScm = NAN;  // mS/cm calibrado
  float ec_uS   = NAN;  // µS/cm calibrado
  float tds_gL  = NAN;  // g/L calibrado
  float volts   = NAN;  // voltaje en A0
  bool ok = false;
};

struct ColorReading {
  uint16_t r=0, g=0, b=0, c=0;
  bool ok = false;
};

struct DistanceReading {
  float cm = NAN;
  bool ok = false;
};
