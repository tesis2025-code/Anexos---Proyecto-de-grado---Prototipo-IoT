#include "Color.h"
#include <Adafruit_TCS34725.h>
#include <Adafruit_NeoPixel.h>

namespace {
  Adafruit_TCS34725 _tcs;
  Adafruit_NeoPixel* _ring = nullptr;
  Color::Config _cfg;

  static uint16_t tcsIntMs(uint8_t it) {
    switch (it) {
      case TCS34725_INTEGRATIONTIME_2_4MS:   return 3;
      case TCS34725_INTEGRATIONTIME_24MS:    return 24;
      case TCS34725_INTEGRATIONTIME_50MS:    return 50;
      case TCS34725_INTEGRATIONTIME_101MS:   return 101;
      case TCS34725_INTEGRATIONTIME_154MS:   return 154;
#ifdef TCS34725_INTEGRATIONTIME_300MS
      case TCS34725_INTEGRATIONTIME_300MS:   return 300;
#endif
#ifdef TCS34725_INTEGRATIONTIME_700MS
      case TCS34725_INTEGRATIONTIME_700MS:   return 700;
#endif
      default: return 154;
    }
  }

  inline void ringFill(uint8_t r, uint8_t g, uint8_t b) {
    if (!_cfg.useRing || !_ring) return;
    for (uint16_t i = 0; i < _cfg.ringCount; ++i)
      _ring->setPixelColor(i, _ring->Color(r,g,b));
    _ring->show();
  }

  inline void readUnderLight(uint8_t lr, uint8_t lg, uint8_t lb,
                             uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c) {
    ringFill(lr, lg, lb);
    delay(_cfg.settleMs + tcsIntMs(_cfg.integration));
    _tcs.getRawData(&r, &g, &b, &c);
  }
}

bool Color::begin(const Config& cfg) {
  _cfg = cfg;

  // Aro
  if (_cfg.useRing) {
    _ring = new Adafruit_NeoPixel(_cfg.ringCount, _cfg.ringPin, NEO_GRB + NEO_KHZ800);
    _ring->begin();
    _ring->setBrightness(_cfg.ringBrightness);
    ringFill(0,0,0);
  }

  // TCS
  if (!_tcs.begin()) {
    return false;
  }

  // Casts necesarios
  _tcs.setIntegrationTime((decltype(TCS34725_INTEGRATIONTIME_154MS)) _cfg.integration);
  _tcs.setGain((decltype(TCS34725_GAIN_4X)) _cfg.gain);

  return true;
}

ColorReading Color::read() {
  ColorReading out;

  if (_cfg.useRing && _ring) {
    // Lecturas bajo R,G,B,W
    uint16_t rR,gR,bR,cR;
    uint16_t rG,gG,bG,cG;
    uint16_t rB,gB,bB,cB;
    uint16_t rW,gW,bW,cW;

    readUnderLight(255,0,0,     rR,gR,bR,cR);
    readUnderLight(0,255,0,     rG,gG,bG,cG);
    readUnderLight(0,0,255,     rB,gB,bB,cB);
    readUnderLight(255,255,255, rW,gW,bW,cW);
    ringFill(0,0,0);

    out.r = (uint16_t)((rR + rG + rB + rW) / 4);
    out.g = (uint16_t)((gR + gG + gB + gW) / 4);
    out.b = (uint16_t)((bR + bG + bB + bW) / 4);
    out.c = cW;
  } else {
    _tcs.getRawData(&out.r, &out.g, &out.b, &out.c);
  }

  out.ok = true;
  return out;
}
