#pragma once
#include <sensors/types.h>
#include <Adafruit_TCS34725.h>

namespace Color {

  struct Config {
    // Aro LED
    uint8_t  ringPin        = 25;
    uint16_t ringCount      = 8;
    uint8_t  ringBrightness = 180;
    bool     useRing        = true;

    // TCS34725
    uint8_t integration = TCS34725_INTEGRATIONTIME_154MS;
    uint8_t gain        = TCS34725_GAIN_4X;

    // Tiempo de estabilización
    uint16_t settleMs = 30;
  };

  bool begin(const Config& cfg = {});
  ColorReading read();
}
