#include "Conductividad.h"
#include <Adafruit_ADS1X15.h>
#include <math.h>

namespace {
  Adafruit_ADS1115 _ads;
  Conductividad::Config _cfg;

  // promedios cortos para suavizar
  const uint8_t N_SAMPLES = 10;

  inline float divK() {
    return (_cfg.R_top + _cfg.R_bot) / _cfg.R_bot; // (Rt+Rb)/Rb
  }

  inline float countsToVolts(int16_t counts) {
    // GAIN_ONE => 0.125 mV/LSB
    return counts * 0.000125f;
  }

  // DFRobot: v_sensor (V reales del SEN0244) -> EC en mS/cm (sin compensar)
  inline float voltageToEC_mScm(float v_sensor) {
    float ec_uS = (133.42f*powf(v_sensor,3.0f) - 255.86f*powf(v_sensor,2.0f) + 857.39f*v_sensor);
    if (ec_uS < 0) ec_uS = 0;
    return ec_uS / 1000.0f; // mS/cm
  }

  inline float compensate25C(float ec_mScm, float tempC) {
    return ec_mScm / (1.0f + _cfg.alpha_temp * (tempC - 25.0f));
  }
}

bool Conductividad::begin(const Config& cfg) {
  _cfg = cfg;
  if (!_ads.begin(_cfg.i2c_addr)) {
    return false;
  }
  _ads.setGain(GAIN_ONE);                 // ±4.096 V
  _ads.setDataRate(RATE_ADS1115_860SPS);  // rápido/estable
  return true;
}

ECReading Conductividad::read(float tempC) {
  ECReading out;

  // Temperatura a usar
  float t = isfinite(tempC) ? tempC : _cfg.default_tempC;

  // Promedio de N lecturas del canal
  long acc = 0;
  for (uint8_t i = 0; i < N_SAMPLES; ++i) {
    acc += _ads.readADC_SingleEnded(_cfg.channel);
    delay(4);
  }
  int16_t counts = (int16_t)(acc / N_SAMPLES);

  // Voltaje en A0 (tras divisor) y voltaje real del sensor
  float v_a0 = countsToVolts(counts);
  float v_sensor = v_a0 * divK();

  // EC sin compensar -> compensada a 25°C
  float ec_mScm_raw = voltageToEC_mScm(v_sensor);
  float ec_mScm_25  = compensate25C(ec_mScm_raw, t);
  float ec_uS_sens  = ec_mScm_25 * 1000.0f; // µS/cm (sensor)

  // TDS base sens (g/L) desde ecuación típica
  float tds_gL_sens = (_cfg.tds_factor * ec_uS_sens) / 1000.0f;

  // Calibraciones finales (tus coeficientes)
  float ec_uS_cal  = _cfg.calA_ec_uS  * ec_uS_sens  + _cfg.calB_ec_uS;
  float tds_gL_cal = _cfg.calA_tds_gL * tds_gL_sens + _cfg.calB_tds_gL;

  // Evitar negativos por ruido/calibración
  if (ec_uS_cal  < 0) ec_uS_cal  = 0;
  if (tds_gL_cal < 0) tds_gL_cal = 0;

  // Llenar salida
  out.volts   = v_a0;                 // útil para debug (volt en A0)
  out.ec_mScm = ec_uS_cal / 1000.0f;  // mS/cm calibrado
  out.ec_uS   = ec_uS_cal;            // µS/cm calibrado
  out.tds_gL  = tds_gL_cal;           // g/L calibrado
  out.ok      = isfinite(out.ec_mScm);

  return out;
}
