#pragma once
#include <sensors/types.h>

namespace Conductividad {

  struct Config {
    // ADS1115
    uint8_t i2c_addr = 0x48;
    uint8_t channel  = 1;        // A1

    // Divisor AOUT->A0 (10k arriba, 20k abajo)
    float R_top = 10000.0f;
    float R_bot = 20000.0f;

    // Compensación térmica (a 25°C)
    float alpha_temp = 0.02f;    // 2%/°C típico
    float default_tempC = 25.0f;

    // Conversión TDS base (ppm ≈ factor * EC(µS/cm))
    float tds_factor = 0.50f;    // 0.50 genérico

    // Calibraciones lineales finales (tus coeficientes)
    float calA_ec_uS = 0.6918799f;
    float calB_ec_uS = -5.3085242f;
    float calA_tds_gL = 1.1015757f;
    float calB_tds_gL = -0.0035140f;
  };

  bool begin(const Config& cfg = {});
  ECReading read(float tempC = NAN); // si envías NAN, usa default_tempC del cfg
}
