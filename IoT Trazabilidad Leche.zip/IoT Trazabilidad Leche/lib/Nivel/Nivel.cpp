#include "Nivel.h"
#include <Arduino.h>

namespace {
  Nivel::Config _cfg;

  // 0.0343 cm/us a 20°C; ida y vuelta => *0.5
  inline float durToCm(uint32_t dur_us) {
    return (dur_us * 0.0343f) * 0.5f;
  }

  // Disparo y medición única
  float medirDistanciaCmOnce() {
    digitalWrite(_cfg.pinTrig, LOW);
    delayMicroseconds(2);
    digitalWrite(_cfg.pinTrig, HIGH);
    delayMicroseconds(10);
    digitalWrite(_cfg.pinTrig, LOW);

    uint32_t dur = pulseIn(_cfg.pinEcho, HIGH, _cfg.echoTimeoutUs);
    if (!dur) return NAN;
    return durToCm(dur);
  }

  // Mediana simple con descarte de primera lectura y manejo de NaN
  float medianaDist(uint8_t N) {
    float v[9];
    N = (N > 9) ? 9 : N;

    // “Warm-up”: algunos HC-SR04 dan 1ro inestable
    (void)medirDistanciaCmOnce();
    delay(_cfg.settleBetweenShotsMs);

    uint8_t validos = 0;
    for (uint8_t i = 0; i < N; ++i) {
      v[i] = medirDistanciaCmOnce();
      if (!isnan(v[i])) validos++;
      delay(_cfg.settleBetweenShotsMs);
    }
    if (validos == 0) return NAN;

    // Ordenamiento con NaN al final (burbuja pequeña)
    for (uint8_t i = 0; i < N; ++i) {
      for (uint8_t j = i + 1; j < N; ++j) {
        bool sw = false;
        if (isnan(v[i]) && !isnan(v[j])) sw = true;
        else if (!isnan(v[i]) && !isnan(v[j]) && v[j] < v[i]) sw = true;
        if (sw) { float t = v[i]; v[i] = v[j]; v[j] = t; }
      }
    }

    uint8_t mid = (validos == N) ? (N / 2) : (validos / 2);
    return v[mid];
  }
}

bool Nivel::begin(const Config& cfg) {
  _cfg = cfg;
  pinMode(_cfg.pinTrig, OUTPUT);
  pinMode(_cfg.pinEcho, INPUT);   // sin pullups; el BSS138 ya hace nivel
  digitalWrite(_cfg.pinTrig, LOW);
  delay(200); // pequeño warm-up
  return true;
}

DistanceReading Nivel::read() {
  DistanceReading out;
  float d = medianaDist(_cfg.samples);
  if (isnan(d)) {
    out.ok = false;
  } else {
    out.cm = d;
    out.ok = true;
  }
  return out;
}
