#pragma once
#include <sensors/types.h>

namespace Nivel {

  struct Config {
    int pinTrig = 23;             // GPIO23 TTGO -> TRIG
    int pinEcho = 35;             // GPIO35 TTGO <- ECHO (via BSS138 a 3.3V)
    unsigned long echoTimeoutUs = 30000UL; // ~5 m
    uint8_t samples = 5;          // lecturas para mediana (máx 9)
    unsigned long settleBetweenShotsMs = 40; // evita rebotes acústicos
  };

  bool begin(const Config& cfg = {});
  DistanceReading read();  // devuelve mediana en cm
}
