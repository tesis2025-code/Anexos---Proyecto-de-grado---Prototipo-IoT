#include "Temperatura.h"
#include <OneWire.h>
#include <DallasTemperature.h>

static OneWire* _ow = nullptr;
static DallasTemperature* _ds = nullptr;

float Temperatura::offset = -0.72f;  // offset calibrado

bool Temperatura::begin(int pin) {
  _ow = new OneWire(pin);
  _ds = new DallasTemperature(_ow);
  _ds->begin();
  return true;
}

TempReading Temperatura::read() {
  TempReading t;
  if(!_ds) return t;

  _ds->requestTemperatures();
  float raw = _ds->getTempCByIndex(0);

  if (raw > -100 && raw < 150) {
    t.c = raw + offset;
    t.ok = true;
  }
  return t;
}
