#pragma once
#include <sensors/types.h>

namespace Temperatura {
  // Inicia el sensor en el pin indicado
  bool begin(int pin);

  // Lee temperatura (con offset calibrado)
  TempReading read();

  // Configuración de calibración
  extern float offset;
}
