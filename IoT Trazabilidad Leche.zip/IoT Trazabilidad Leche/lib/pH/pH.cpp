#include "pH.h"
#include <Adafruit_ADS1X15.h>

static Adafruit_ADS1115 _ads;
static PH::Config _cfg;

bool PH::begin(const Config& cfg) {
  _cfg = cfg;
  if (!_ads.begin(_cfg.i2c_addr)) {
    return false;
  }
  _ads.setGain(GAIN_ONE);                 // ±4.096V
  _ads.setDataRate(RATE_ADS1115_860SPS);  // rápido y estable
  return true;
}

PHReading PH::read() {
  PHReading r;
  // Lectura de un canal single-ended
  int16_t raw = _ads.readADC_SingleEnded(_cfg.channel);
  float v = _ads.computeVolts(raw);  // usa el gain configurado
  r.volts = v;

  // pH con tu ecuación calibrada
  r.ph = _cfg.m * v + _cfg.b;
  r.ok = isfinite(r.ph);
  return r;
}
