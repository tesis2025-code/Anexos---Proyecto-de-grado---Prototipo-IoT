#pragma once
#include <sensors/types.h>

namespace PH {
  struct Config {
    uint8_t i2c_addr = 0x48;   // ADS1115 típico
    uint8_t channel  = 0;      // A0
    float m = 1.02f;           // tu calibración
    float b = -0.08f;          // tu calibración
  };

  // Llama esto una vez en setup (Wire.begin lo hace el main)
  bool begin(const Config& cfg = {});

  // Lee el voltaje de A0 y calcula pH usando m y b
  PHReading read();
}
