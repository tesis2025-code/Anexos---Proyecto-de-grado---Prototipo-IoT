#include <Arduino.h>
#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_ADS1X15.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <esp_task_wdt.h>

// ========== CONFIGURACIÓN ==========
// Tiempos (ms)
#define SENSOR_READ_PERIOD 10000      // Captura cada 10s
#define THINGSPEAK_PERIOD 20000       // Envío cada 20s (mínimo TS)
#define OLED_UPDATE_PERIOD 500        // Actualizar OLED cada 500ms
#define WIFI_RECONNECT_TIMEOUT 30000  // Intentar reconectar WiFi por 30s
#define ADS_RETRY_PERIOD 5000         // Reintentar ADS cada 5s
#define WATCHDOG_TIMEOUT 60           // Watchdog a 60s
#define OLED_SCREEN_TIME 3000         // Tiempo por pantalla (3s)

#define MAX_BUFFER_SIZE 20            // Máximo 20 lecturas en buffer

// Pines
#define ONE_WIRE_BUS 4
#define HCSR04_TRIG 23
#define HCSR04_ECHO 35
#define I2C_SDA 21
#define I2C_SCL 22
#define ECHO_TIMEOUT_US 30000UL

// OLED
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDR 0x3C

// ===== CALIBRACIONES (basadas en datos experimentales) =====

// Temperatura DS18B20: Temp_Real = m_temp × Temp_Sensor + b_temp
const float m_temp = 0.8526f;
const float b_temp = 2.3947f;

// pH: pH_Real = m_ph × pH_Sensor + b_ph
const float m_ph = -1.1733f;
const float b_ph = 11.2644f;

// TDS: TDS_Real = m_tds × TDS_Sensor + b_tds
const float m_tds = 5.3172f;
const float b_tds = -0.9076f;

// Conductividad: EC_Real = m_ec × EC_Sensor + b_ec
const float m_ec = 2.4961f;
const float b_ec = 202.45f;

// WiFi & ThingSpeak
const char *ssid = "HONOR 400 Smart";
const char *password = "12345678";
const String apiKey = "Y6A6THY2L6DK7P0O";
const String urlTS = "http://api.thingspeak.com/update";

// ========== OBJETOS GLOBALES ==========
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature ds18(&oneWire);
Adafruit_ADS1115 ads;
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ========== ESTRUCTURAS DE DATOS ==========
struct SensorData {
  float temperatura;
  float distancia;
  float ph;
  float tds;
  float conductividad;
  unsigned long timestamp;
};

struct SystemState {
  bool wifi_connected;
  bool ads_available;
  uint8_t buffer_count;
  uint8_t wifi_retry_count;
  unsigned long uptime_s;
  bool sending_data;
  String last_error;
};

// ========== VARIABLES GLOBALES ==========
SensorData buffer[MAX_BUFFER_SIZE];
uint8_t buffer_index = 0;
SystemState sys_state = {false, false, 0, 0, 0, false, ""};

// Timers no bloqueantes
unsigned long last_sensor_read = 0;
unsigned long last_ts_send = 0;
unsigned long last_oled_update = 0;
unsigned long last_ads_retry = 0;
unsigned long last_screen_change = 0;
unsigned long wifi_reconnect_start = 0;
unsigned long boot_time = 0;

// Estado OLED
enum OLEDScreen { SCREEN_DATA, SCREEN_STATUS, SCREEN_ALERTS };
OLEDScreen current_screen = SCREEN_DATA;
bool force_oled_update = true;

// ========== FUNCIONES AUXILIARES ==========

// Sanear valores
float sane(float v, float fallback) {
  return (isnan(v) || isinf(v)) ? fallback : v;
}

// Feed watchdog
void feedWatchdog() {
  esp_task_wdt_reset();
}

// ========== SENSORES ==========

// HC-SR04
float medirDistanciaCm() {
  digitalWrite(HCSR04_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(HCSR04_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(HCSR04_TRIG, LOW);
  
  uint32_t dur = pulseIn(HCSR04_ECHO, HIGH, ECHO_TIMEOUT_US);
  if (!dur) return NAN;
  return (dur * 0.0343f) / 2.0f;
}

float medianaDist(uint8_t N = 5) {
  float v[9];
  N = min<uint8_t>(N, 9);
  
  for (uint8_t i = 0; i < N; i++) {
    v[i] = medirDistanciaCm();
    delay(30);
    feedWatchdog();
  }
  
  // Ordenar
  for (uint8_t i = 0; i < N; i++) {
    for (uint8_t j = i + 1; j < N; j++) {
      if (isnan(v[i]) || (!isnan(v[j]) && v[j] < v[i])) {
        float t = v[i]; v[i] = v[j]; v[j] = t;
      }
    }
  }
  return v[N / 2];
}

// pH (ADS1115 A0)
float readPH() {
  if (!sys_state.ads_available) return 7.0f; // Fallback neutral
  
  int32_t acc = 0;
  for (int i = 0; i < 10; i++) {
    acc += ads.readADC_SingleEnded(0);
    delay(5);
  }
  int16_t raw = acc / 10;
  float V = (raw * 4.096f) / 32767.0f;
  
  // Convertir voltaje a pH "crudo"
  float pH_raw = -5.905f * V + 16.024f;
  
  // Aplicar calibración final
  float pH_calibrado = m_ph * pH_raw + b_ph;
  
  return pH_calibrado;
}

// TDS (ADS1115 A1)
void readTDSraw(int16_t &raw, float &V) {
  if (!sys_state.ads_available) {
    raw = 0;
    V = 0.0f;
    return;
  }
  
  int32_t acc = 0;
  for (int i = 0; i < 10; i++) {
    acc += ads.readADC_SingleEnded(1);
    delay(5);
  }
  raw = acc / 10;
  V = (raw * 4.096f) / 32767.0f;
}

float convertTDS(int16_t /*tds_raw*/, float voltage) {
  float tds_raw = 0.5f * voltage;
  float tds_calibrado = m_tds * tds_raw + b_tds;
  return max(0.0f, tds_calibrado);
}

float convertConductivity(int16_t /*tds_raw*/, float voltage) {
  float conductivity_raw = 1000.0f * voltage;
  float conductivity_calibrada = m_ec * conductivity_raw + b_ec;
  return max(0.0f, conductivity_calibrada);
}

// ========== CAPTURA DE DATOS ==========
void capturarSnapshot(SensorData &data) {
  // Acumuladores
  float pH_acc = 0, tds_acc = 0, dist_acc = 0, temp_acc = 0, cond_acc = 0;
  const uint8_t num_measurements = 4;
  
  for (uint8_t i = 0; i < num_measurements; i++) {
    float ph = readPH();
    int16_t tds_raw;
    float tds_V;
    readTDSraw(tds_raw, tds_V);
    float tds_gL = convertTDS(tds_raw, tds_V);
    float cond_uS = convertConductivity(tds_raw, tds_V);
    float dcm = medianaDist(5);
    
    ds18.requestTemperatures();
    float tC_raw = ds18.getTempCByIndex(0);
    float tC = (tC_raw == DEVICE_DISCONNECTED_C) ? DEVICE_DISCONNECTED_C : 
               (m_temp * tC_raw + b_temp);
    
    pH_acc += ph;
    tds_acc += tds_gL;
    dist_acc += dcm;
    temp_acc += tC;
    cond_acc += cond_uS;
    
    feedWatchdog();
  }
  
  data.temperatura = sane(temp_acc / num_measurements, -127.0f);
  data.distancia = sane(dist_acc / num_measurements, 0.0f);
  data.ph = sane(pH_acc / num_measurements, 7.0f);
  data.tds = sane(tds_acc / num_measurements, 0.0f);
  data.conductividad = sane(cond_acc / num_measurements, 0.0f);
  data.timestamp = millis();
  
  Serial.println("==== SNAPSHOT CAPTURADO ====");
  Serial.printf("T=%.2f D=%.2f pH=%.2f TDS=%.3f EC=%.1f\n",
                data.temperatura, data.distancia, data.ph, data.tds, data.conductividad);
}

// ========== BUFFER ==========
void agregarAlBuffer(const SensorData &data) {
  if (buffer_index < MAX_BUFFER_SIZE) {
    buffer[buffer_index++] = data;
    sys_state.buffer_count = buffer_index;
    Serial.printf("Buffer: %u/%u\n", buffer_index, MAX_BUFFER_SIZE);
  } else {
    Serial.println("⚠️ Buffer lleno! Datos perdidos.");
    sys_state.last_error = "Buffer lleno";
  }
}

// ========== THINGSPEAK ==========
bool enviarAThingSpeak(const SensorData &data) {
  if (WiFi.status() != WL_CONNECTED) return false;
  
  sys_state.sending_data = true;
  force_oled_update = true;
  
  HTTPClient http;
  String requestUrl = urlTS +
                      "?api_key=" + apiKey +
                      "&field1=" + String(data.distancia, 2) +
                      "&field2=" + String(data.temperatura, 2) +
                      "&field3=" + String(data.ph, 2) +
                      "&field4=" + String(data.tds, 3) +
                      "&field5=" + String(data.conductividad, 1);
  
  Serial.println("Enviando a TS: " + requestUrl);
  http.begin(requestUrl);
  int httpCode = http.GET();
  http.end();
  
  sys_state.sending_data = false;
  force_oled_update = true;
  
  if (httpCode > 0) {
    Serial.printf("✓ ThingSpeak OK: HTTP %d\n", httpCode);
    return true;
  } else {
    Serial.printf("✗ ThingSpeak ERROR: %d\n", httpCode);
    sys_state.last_error = "TS Error:" + String(httpCode);
    return false;
  }
}

void enviarBuffer() {
  if (buffer_index == 0) return;
  
  Serial.printf("Enviando buffer (%u lecturas)...\n", buffer_index);
  
  for (uint8_t i = 0; i < buffer_index; i++) {
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("WiFi perdido durante envío de buffer");
      return;
    }
    
    if (enviarAThingSpeak(buffer[i])) {
      Serial.printf("  [%u/%u] ✓\n", i + 1, buffer_index);
    } else {
      Serial.printf("  [%u/%u] ✗ Falló\n", i + 1, buffer_index);
      return;
    }
    
    delay(15500);
    feedWatchdog();
  }
  
  buffer_index = 0;
  sys_state.buffer_count = 0;
  Serial.println("✓ Buffer enviado completamente");
}

// ========== WiFi ==========
void intentarReconectarWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    sys_state.wifi_connected = true;
    sys_state.wifi_retry_count = 0;
    return;
  }
  
  if (wifi_reconnect_start == 0) {
    wifi_reconnect_start = millis();
    sys_state.wifi_retry_count = 0;
    Serial.println("WiFi desconectado. Iniciando reconexión...");
  }
  
  if (millis() - wifi_reconnect_start > WIFI_RECONNECT_TIMEOUT) {
    Serial.println("✗ Timeout de reconexión WiFi");
    sys_state.last_error = "WiFi timeout";
    wifi_reconnect_start = 0;
    sys_state.wifi_connected = false;
    return;
  }
  
  sys_state.wifi_retry_count++;
  Serial.printf("Intento WiFi %u...\n", sys_state.wifi_retry_count);
  force_oled_update = true;
  
  WiFi.disconnect();
  WiFi.begin(ssid, password);
  
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 5000) {
    delay(100);
    feedWatchdog();
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("✓ WiFi reconectado! IP: " + WiFi.localIP().toString());
    sys_state.wifi_connected = true;
    sys_state.wifi_retry_count = 0;
    sys_state.last_error = "";
    wifi_reconnect_start = 0;
    force_oled_update = true;
  } else {
    sys_state.wifi_connected = false;
  }
}

// ========== ADS1115 ==========
void intentarInicializarADS() {
  Serial.println("Intentando inicializar ADS1115...");
  
  if (ads.begin()) {
    ads.setGain(GAIN_ONE);
    sys_state.ads_available = true;
    sys_state.last_error = "";
    Serial.println("✓ ADS1115 inicializado");
    force_oled_update = true;
  } else {
    sys_state.ads_available = false;
    sys_state.last_error = "ADS1115 error";
    Serial.println("✗ ADS1115 no detectado");
  }
}

// ========== OLED ==========
void cambiarPantalla() {
  if (sys_state.last_error != "" || !sys_state.wifi_connected || !sys_state.ads_available) {
    if (current_screen == SCREEN_DATA && millis() - last_screen_change > 8000) {
      current_screen = SCREEN_ALERTS;
      last_screen_change = millis();
    } else if (current_screen == SCREEN_ALERTS && millis() - last_screen_change > OLED_SCREEN_TIME) {
      current_screen = SCREEN_DATA;
      last_screen_change = millis();
    }
  } else {
    if (millis() - last_screen_change > OLED_SCREEN_TIME) {
      if (current_screen == SCREEN_DATA) {
        current_screen = SCREEN_STATUS;
      } else {
        current_screen = SCREEN_DATA;
      }
      last_screen_change = millis();
      force_oled_update = true;
    }
  }
}

void dibujarPantallaData(const SensorData &data) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  
  display.setCursor(0, 0);
  display.print("T:");
  if (data.temperatura == -127.0f) display.print("--");
  else { display.print(data.temperatura, 1); display.print("C"); }
  
  display.print("  D:");
  if (data.distancia == 0.0f) display.print("--");
  else { display.print(data.distancia, 0); display.print("cm"); }
  
  display.setCursor(110, 0);
  display.print(sys_state.wifi_connected ? "W" : "X");
  
  display.setCursor(0, 16);
  display.print("pH: ");
  display.print(data.ph, 2);
  
  display.setCursor(0, 32);
  display.print("TDS: ");
  display.print(data.tds, 3);
  display.print(" g/L");
  
  display.setCursor(0, 48);
  display.print("EC: ");
  display.print(data.conductividad, 1);
  display.print(" uS");
  
  if (sys_state.sending_data) {
    display.setCursor(110, 56);
    display.print("^");
  }
  
  display.display();
}

void dibujarPantallaStatus() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  
  display.setCursor(0, 0);
  display.println("=== SISTEMA ===");
  
  display.print("WiFi: ");
  display.println(sys_state.wifi_connected ? "OK" : "ERROR");
  
  display.print("ADS1115: ");
  display.println(sys_state.ads_available ? "OK" : "ERROR");
  
  display.print("Buffer: ");
  display.print(sys_state.buffer_count);
  display.print("/");
  display.println(MAX_BUFFER_SIZE);
  
  display.print("Uptime: ");
  unsigned long mins = sys_state.uptime_s / 60;
  display.print(mins / 60);
  display.print("h");
  display.print(mins % 60);
  display.println("m");
  
  display.display();
}

void dibujarPantallaAlertas() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  
  display.setCursor(0, 0);
  display.println("!!! ALERTAS !!!");
  display.println();
  
  if (!sys_state.wifi_connected) {
    display.println("WiFi: Desconectado");
    if (sys_state.wifi_retry_count > 0) {
      display.print("Intento: ");
      display.println(sys_state.wifi_retry_count);
    }
  }
  
  if (!sys_state.ads_available) {
    display.println("ADS1115: Error");
  }
  
  if (sys_state.buffer_count > 15) {
    display.print("Buffer: ");
    display.print(sys_state.buffer_count);
    display.println("/20");
  }
  
  if (sys_state.last_error != "") {
    display.println();
    display.print("Err: ");
    display.println(sys_state.last_error);
  }
  
  display.display();
}

void actualizarOLED(const SensorData &data) {
  cambiarPantalla();
  
  switch (current_screen) {
    case SCREEN_DATA:
      dibujarPantallaData(data);
      break;
    case SCREEN_STATUS:
      dibujarPantallaStatus();
      break;
    case SCREEN_ALERTS:
      dibujarPantallaAlertas();
      break;
  }
  
  force_oled_update = false;
}

// ========== SETUP ==========
void setup() {
  delay(3000);
  
  Serial.begin(115200);
  delay(500);
  boot_time = millis();
  
  esp_reset_reason_t reset_reason = esp_reset_reason();
  Serial.print("Reset reason: ");
  switch(reset_reason) {
    case ESP_RST_POWERON: Serial.println("Power-on"); break;
    case ESP_RST_SW: Serial.println("Software"); break;
    case ESP_RST_PANIC: Serial.println("Panic/Exception"); break;
    case ESP_RST_INT_WDT: Serial.println("Watchdog (interrupt)"); break;
    case ESP_RST_TASK_WDT: Serial.println("Watchdog (task)"); break;
    case ESP_RST_WDT: Serial.println("Watchdog (other)"); break;
    case ESP_RST_BROWNOUT: Serial.println("Brownout"); break;
    default: Serial.println("Unknown"); break;
  }
  
  if (reset_reason == ESP_RST_PANIC || 
      reset_reason == ESP_RST_WDT || 
      reset_reason == ESP_RST_BROWNOUT) {
    Serial.println("⚠️ Reset anormal - esperando 5s antes de continuar");
    delay(5000);
  }
  
  esp_task_wdt_init(WATCHDOG_TIMEOUT, true);
  esp_task_wdt_add(NULL);
  Serial.println("✓ Watchdog activado (60s)");
  
  pinMode(HCSR04_TRIG, OUTPUT);
  pinMode(HCSR04_ECHO, INPUT);
  digitalWrite(HCSR04_TRIG, LOW);
  
  Wire.begin(I2C_SDA, I2C_SCL);
  
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("❌ OLED no detectado - CRÍTICO");
    while (1) { delay(1000); feedWatchdog(); }
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Iniciando...");
  display.display();
  Serial.println("✓ OLED OK");
  
  ds18.begin();
  Serial.println("✓ DS18B20 OK");
  
  intentarInicializarADS();
  
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Conectando WiFi...");
  display.display();
  
  WiFi.begin(ssid, password);
  unsigned long wifi_start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifi_start < 10000) {
    delay(500);
    Serial.print(".");
    feedWatchdog();
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    sys_state.wifi_connected = true;
    Serial.println("\n✓ WiFi OK! IP: " + WiFi.localIP().toString());
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("WiFi: OK");
    display.println(WiFi.localIP());
    display.display();
    delay(2000);
  } else {
    sys_state.wifi_connected = false;
    Serial.println("\n⚠️ WiFi inicial falló - continuando en modo offline");
  }
  
  last_sensor_read = millis() - SENSOR_READ_PERIOD;
  last_ts_send = millis();
  last_oled_update = millis();
  last_screen_change = millis();
  
  Serial.println("\n========== SISTEMA LISTO ==========\n");
}

// ========== LOOP ==========
void loop() {
  feedWatchdog();
  
  unsigned long now = millis();
  
  sys_state.uptime_s = (now - boot_time) / 1000;
  
  if (now - last_sensor_read >= SENSOR_READ_PERIOD) {
    SensorData nueva_lectura;
    capturarSnapshot(nueva_lectura);
    agregarAlBuffer(nueva_lectura);
    last_sensor_read = now;
    force_oled_update = true;
  }
  
  bool debe_enviar = (now - last_ts_send >= THINGSPEAK_PERIOD) && 
                     sys_state.wifi_connected &&
                     buffer_index > 0;
  
  bool buffer_lleno = buffer_index >= MAX_BUFFER_SIZE;
  
  if (debe_enviar || buffer_lleno) {
    enviarBuffer();
    last_ts_send = now;
  }
  
  if (now - last_oled_update >= OLED_UPDATE_PERIOD || force_oled_update) {
    SensorData ultima = (buffer_index > 0) ? buffer[buffer_index - 1] : SensorData{0};
    actualizarOLED(ultima);
    last_oled_update = now;
  }
  
  if (!sys_state.ads_available && now - last_ads_retry >= ADS_RETRY_PERIOD) {
    intentarInicializarADS();
    last_ads_retry = now;
  }
  
  if (!sys_state.wifi_connected) {
    intentarReconectarWiFi();
  } else {
    wifi_reconnect_start = 0;
  }
  
  delay(10);
}