# app/analysis.py
from __future__ import annotations
from dataclasses import dataclass
from statistics import median
from typing import Dict, List, Tuple, Optional
import math

@dataclass
class AnalysisConfig:
    """Configuración de parámetros para análisis de leche"""
    
    # Geometría del contenedor
    RADIUS_CM: float = 16.5
    MAX_H_CM: float = 46.5
    
    # Configuración de baseline
    N_BASELINE: int = 20          # cuántas lecturas pedir a ThingSpeak para baseline
    TDS_BASE_DEFAULT: float = 0.30  # g/L baseline provisional si no hay histórico

    # ========== COEFICIENTES AJUSTADOS ==========
    
    # Densidad (g/mL): densidad = 1.028 + A1*(CE_mS-5) + A2*tds_rel - A3*(T-4)
    A1: float = 0.01   # Conductividad → densidad (reducido de 0.02)
    A2: float = 0.10   # TDS relativo → densidad (reducido de 0.30)
    A3: float = 0.001  # Temperatura → densidad (ajustado para -0.004 por cada 4°C)
    
    # Sólidos Totales (%): ST = B1*CE_mS + B2*tds_rel
    B1: float = 1.8    # CE → %ST (aumentado de 1.6 para rango 9-13%)
    B2: float = 3.0    # TDS rel → %ST (reducido de 8.0)
    
    # Grasa (%): Fat = C0 + C1/CE_mS + C2*tds_rel - C3*(T-6)
    C0: float = 2.5    # Base (ajustado de 2.8)
    C1: float = 3.5    # Inversa CE → grasa (aumentado de 3.0)
    C2: float = 0.5    # TDS rel → grasa (reducido de 1.0)
    C3: float = 0.2    # Penalización por temperatura alta

    # ========== UMBRALES DE ADULTERACIÓN ==========
    PH_MIN: float = 6.4        # pH mínimo normal
    PH_MAX: float = 6.9        # pH máximo normal
    CE_MIN_uS: float = 3500.0  # CE mínima (debajo = aguado)
    CE_MAX_uS: float = 6500.0  # CE máxima (arriba = sales añadidas)
    TDS_REL_MAX: float = 0.30  # +30% sobre baseline
    TDS_REL_MIN: float = -0.20 # -20% bajo baseline (aguado)
    DENSIDAD_MIN: float = 1.024 # g/mL mínima (debajo = aguado)
    TEMP_MAX_OK: float = 8.0   # °C máxima recomendada (refrigeración)

# ---------- Utilidades numéricas ----------
def _to_float(x) -> Optional[float]:
    """Convierte a float, retorna None si falla"""
    try:
        if x is None:
            return None
        return float(x)
    except Exception:
        return None

def _clamp(v: float, lo: float, hi: float) -> float:
    """Limita un valor entre mínimo y máximo"""
    return max(lo, min(hi, v))

# ---------- Baseline de TDS sobre histórico ----------
def compute_tds_baseline(feeds: List[Dict], default_base: float) -> Tuple[float, int]:
    """
    Calcula baseline de TDS (mediana) usando TODAS las lecturas menos la última.
    
    Args:
        feeds: Lista de feeds de ThingSpeak (cada uno con 'field4' = TDS)
        default_base: Valor por defecto si no hay suficientes datos
    
    Returns:
        (baseline_tds, n_muestras_usadas)
    """
    if not feeds or len(feeds) < 2:
        return (default_base, 0)

    prev = []
    for f in feeds[:-1]:  # excluir la última (actual)
        tds = _to_float(f.get("field4"))
        if tds is not None and math.isfinite(tds):
            prev.append(tds)

    if len(prev) >= 3:
        return (median(prev), len(prev))
    return (default_base, len(prev))

# ---------- Análisis directo ----------
def analizar_directo(data: Dict) -> Dict:
    """
    Análisis directo: valida temperatura, pH y conductividad contra rangos normales.
    
    Args:
        data: dict con keys: temperature (°C), ph, conductivity (µS/cm)
    
    Returns:
        dict con flags booleanos y etiqueta de calidad
    """
    t = _to_float(data.get("temperature"))
    ph = _to_float(data.get("ph"))
    ce_uS = _to_float(data.get("conductivity"))

    # Rangos normales para leche refrigerada de calidad
    temp_ok = (t is not None) and (2.0 <= t <= 6.0)
    ph_ok   = (ph is not None) and (6.6 <= ph <= 6.8)
    ce_ok   = (ce_uS is not None) and (4000.0 <= ce_uS <= 6000.0)

    # Clasificación por puntuación
    score = sum([temp_ok, ph_ok, ce_ok])
    if score == 3:
        calidad = "buena"
    elif score == 2:
        calidad = "regular"
    else:
        calidad = "mala"

    return {
        "temperatura_ok": temp_ok,
        "ph_ok": ph_ok,
        "conductividad_ok": ce_ok,
        "leche_calidad": calidad,
    }

# ---------- Análisis indirecto ----------
def analizar_indirecto(data: Dict, cfg: AnalysisConfig, tds_baseline: float, baseline_count: int) -> Dict:
    """
    Análisis indirecto: calcula volumen, densidad, %ST, %grasa y detecta adulteración.
    
    Args:
        data: dict con distance, temperature, ph, tds, conductivity
        cfg: AnalysisConfig con parámetros y coeficientes
        tds_baseline: Baseline calculado de TDS (g/L)
        baseline_count: Número de muestras usadas para calcular baseline
    
    Returns:
        dict con estimaciones y flags de adulteración
    """
    dist = _to_float(data.get("distance"))      # cm
    t    = _to_float(data.get("temperature"))   # °C
    ph   = _to_float(data.get("ph"))
    tds  = _to_float(data.get("tds"))           # g/L
    ce_uS = _to_float(data.get("conductivity")) # µS/cm

    # ========== VOLUMEN Y ALTURA ==========
    if dist is None:
        h_cm = None
        vol_L = None
    else:
        h_cm = _clamp(cfg.MAX_H_CM - dist, 0.0, cfg.MAX_H_CM)
        # Volumen cilíndrico: V = π*r²*h (cm³) → litros
        vol_L = math.pi * (cfg.RADIUS_CM ** 2) * h_cm / 1000.0

    # CE a mS/cm para fórmulas
    ce_mS = (ce_uS / 1000.0) if ce_uS is not None else None

    # ========== TDS RELATIVO ==========
    # Cambio porcentual respecto al baseline
    if tds is not None and tds_baseline and tds_baseline > 0:
        tds_rel = _clamp((tds - tds_baseline) / tds_baseline, -1.0, 1.0)
    else:
        tds_rel = None

    # ========== DENSIDAD ESTIMADA (g/mL) ==========
    # Base típica de leche: 1.028 g/mL
    densidad = None
    if ce_mS is not None:
        densidad = 1.028 + cfg.A1 * (ce_mS - 5.0)
        if tds_rel is not None:
            densidad += cfg.A2 * tds_rel
        if t is not None:
            densidad -= cfg.A3 * (t - 4.0)
        # Limitar a rangos físicamente posibles
        densidad = _clamp(densidad, 1.010, 1.040)

    # ========== SÓLIDOS TOTALES % ==========
    solidos_tot = None
    if ce_mS is not None:
        solidos_tot = cfg.B1 * ce_mS
        if tds_rel is not None:
            solidos_tot += cfg.B2 * tds_rel
        # Rango típico: 8-15% (ajustado de 6-18%)
        solidos_tot = _clamp(solidos_tot, 8.0, 15.0)

    # ========== % GRASA ==========
    # Relación inversa con CE (más agua → menor CE → menos grasa)
    grasa = None
    if ce_mS is not None and ce_mS > 0:
        grasa = cfg.C0 + (cfg.C1 / ce_mS)
        if tds_rel is not None:
            grasa += cfg.C2 * tds_rel
        # Penalizar si temperatura está alta (grasa se separa)
        if t is not None and t > 6.0:
            grasa -= cfg.C3 * (t - 6.0)
        # Rango típico: 0.5-5.0%
        grasa = _clamp(grasa, 0.5, 5.0)

    # ========== DETECCIÓN DE ADULTERACIÓN ==========
    adulteracion = False
    razones = []

    # 1. pH fuera de rango normal
    if ph is not None:
        if ph < cfg.PH_MIN:
            adulteracion = True
            razones.append(f"pH bajo ({ph:.2f} < {cfg.PH_MIN}) - posible acidificación")
        elif ph > cfg.PH_MAX:
            adulteracion = True
            razones.append(f"pH alto ({ph:.2f} > {cfg.PH_MAX}) - posible neutralizante")

    # 2. Conductividad anómala
    if ce_uS is not None:
        if ce_uS > cfg.CE_MAX_uS:
            adulteracion = True
            razones.append(f"CE alta ({ce_uS:.0f} > {cfg.CE_MAX_uS} µS/cm) - posible adición de sales")
        elif ce_uS < cfg.CE_MIN_uS:
            adulteracion = True
            razones.append(f"CE baja ({ce_uS:.0f} < {cfg.CE_MIN_uS} µS/cm) - posible aguado")

    # 3. TDS relativo anómalo
    if tds_rel is not None:
        if tds_rel > cfg.TDS_REL_MAX:
            adulteracion = True
            razones.append(f"TDS alto ({tds_rel*100:.1f}% sobre baseline) - posible adición sólidos")
        elif tds_rel < cfg.TDS_REL_MIN:
            adulteracion = True
            razones.append(f"TDS bajo ({tds_rel*100:.1f}% bajo baseline) - posible aguado")

    # 4. Densidad baja (aguado)
    if densidad is not None and densidad < cfg.DENSIDAD_MIN:
        adulteracion = True
        razones.append(f"Densidad baja ({densidad:.3f} < {cfg.DENSIDAD_MIN} g/mL) - posible aguado")

    # 5. Temperatura inadecuada (no es adulteración, pero es problema de calidad)
    if t is not None and t > cfg.TEMP_MAX_OK:
        razones.append(f"Temperatura alta ({t:.1f}°C > {cfg.TEMP_MAX_OK}°C) - riesgo microbiológico")

    # Retornar resultados
    return {
        "volumen_L": vol_L,
        "altura_lleno_cm": h_cm,
        "densidad_est": densidad,
        "solidos_totales_est_pct": solidos_tot,
        "grasa_est_pct": grasa,
        "tds_baseline_gL": tds_baseline,
        "tds_rel": tds_rel,
        "baseline_muestras": baseline_count,
        "adulteracion_sospechosa": adulteracion,
        "razones_adulteracion": razones,  # ← NUEVO: lista de strings
    }