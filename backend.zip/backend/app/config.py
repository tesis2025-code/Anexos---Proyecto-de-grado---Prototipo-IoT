import os
from dotenv import load_dotenv

# Leer las variables desde .env 
load_dotenv()

class Config:
    # Configuración de la conexión con ThingSpeak
    THINGSPEAK_API_KEY = os.getenv("THINGSPEAK_API_KEY")
    CHANNEL_ID = "3098628"  
    THINGSPEAK_URL = f"https://api.thingspeak.com/channels/{CHANNEL_ID}/feeds.json?api_key={THINGSPEAK_API_KEY}"
    
    # Configuración de la conexión con base de datos
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL")  
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    DB_SCHEMA = os.getenv("DB_SCHEMA")

    TS_POST_PERIOD_SEC = 20
