from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from .config import Config

engine = create_engine(Config.SQLALCHEMY_DATABASE_URI)

# Usa el esquema de .env (DB_SCHEMA=TGA). Si no hay, cae a 'dbo'.
metadata = MetaData(schema=(Config.DB_SCHEMA or "dbo"))
Base = declarative_base(metadata=metadata)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
