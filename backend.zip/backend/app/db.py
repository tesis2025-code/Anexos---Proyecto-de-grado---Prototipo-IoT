# app/db.py
from sqlalchemy.orm import Session
from .models import Lectura
from datetime import datetime, timezone
from .database import Base, engine

def _parse_dt(ts):
    if not ts:
        return datetime.utcnow()
    # "2025-10-28T23:49:52Z"
    return datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(timezone.utc).replace(tzinfo=None)


def guardar_lectura(session: Session, data: dict, directo: dict, indirecto: dict):
    """Inserta una nueva lectura. Confía en el índice único (device_id, ts_entry_id)."""
    # Si viene marcado por el ingestor:
    ts_entry_id = int(data.get("_ts_entry_id") or 0)

    lectura = Lectura(
        device_id="TTGO-01",
        ts_entry_id=ts_entry_id,
        fecha_hora=_parse_dt(data.get("timestamp")),

        distance=float(data.get("distance") or 0),
        temperature=float(data.get("temperature") or 0),
        ph=float(data.get("ph") or 0),
        tds=float(data.get("tds") or 0),
        conductivity=float(data.get("conductivity") or 0),
        r=int(data.get("r") or 0),
        g=int(data.get("g") or 0),
        b=int(data.get("b") or 0),

        temperatura_ok=directo.get("temperatura_ok"),
        ph_ok=directo.get("ph_ok"),
        conductividad_ok=directo.get("conductividad_ok"),
        leche_calidad=directo.get("leche_calidad"),

        volumen_L=indirecto.get("volumen_L"),
        densidad_est=indirecto.get("densidad_est"),
        solidos_totales_est_pct=indirecto.get("solidos_totales_est_pct"),
        grasa_est_pct=indirecto.get("grasa_est_pct"),
        adulteracion_sospechosa=indirecto.get("adulteracion_sospechosa"),
    )
    session.add(lectura)
    session.commit()

def init_db(app=None):
    """
    Inicializa la base de datos (solo asegura conexión).
    Ya no crea tablas, porque las generamos manualmente en SQL Server.
    """
    try:
        # Probar la conexión
        with engine.connect() as conn:
            print("✅ Conexión a SQL Server establecida correctamente.")
    except Exception as e:
        print(f"❌ Error al conectar con la base de datos: {e}")