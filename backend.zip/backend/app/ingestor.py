# app/ingestor.py
import os, time, threading
from datetime import datetime, timezone
from .database import SessionLocal
from .utils import get_thingspeak_feeds, parse_feed_to_sensor_dict, validate_data
from .analysis import AnalysisConfig, compute_tds_baseline, analizar_directo, analizar_indirecto
from .db import guardar_lectura
from .models import Lectura

POLL_SECONDS = int(os.getenv("POLL_SECONDS", "60"))  # o en Config

def _get_max_entry_id(session, device_id="TTGO-01"):
    q = session.query(Lectura.ts_entry_id).filter(Lectura.device_id==device_id)\
        .order_by(Lectura.ts_entry_id.desc()).limit(1)
    row = q.first()
    return row[0] if row and row[0] is not None else 0

def ingest_once():
    """Lee N feeds, filtra los nuevos por entry_id y los inserta en orden cronológico."""
    feeds = get_thingspeak_feeds(20)
    if not feeds:
        return 0

    # baseline para TDS (usa todos los feeds)
    cfg = AnalysisConfig()
    tds_base, n_used = compute_tds_baseline(feeds, cfg.TDS_BASE_DEFAULT)

    sess = SessionLocal()
    inserted = 0
    try:
        last_entry = _get_max_entry_id(sess, "TTGO-01")

        # Parsear y quedarnos SOLO con los feeds nuevos
        parsed = []
        for f in feeds:
            d = parse_feed_to_sensor_dict(f)
            eid = d.get("entry_id")
            if eid is None:
                continue
            if int(eid) > int(last_entry):
                parsed.append(d)

        # Insertar en orden ascendente de entry_id
        parsed.sort(key=lambda x: int(x["entry_id"]))

        for data in parsed:
            # Validación (sin TDS duro)
            valid, errors = validate_data({
                "distance": data["distance"],
                "temperature": data["temperature"],
                "ph": data["ph"],
                "conductivity": data["conductivity"],
                "r": data["r"], "g": data["g"], "b": data["b"]
            })
            if not valid:
                # puedes loggear errors si quieres
                continue

            directo = analizar_directo(data)
            indirecto = analizar_indirecto(data, cfg, tds_base, n_used)

            # Marcar entry_id en los datos para guardar
            data["_ts_entry_id"] = int(data["entry_id"])

            guardar_lectura(sess, data, directo, indirecto)
            inserted += 1

        return inserted
    except Exception as e:
        sess.rollback()
        print(f"[ingestor] Error: {e}")
        return inserted
    finally:
        sess.close()

def run_ingestor_forever():
    print(f"[ingestor] Iniciando loop cada {POLL_SECONDS}s …")
    while True:
        try:
            n = ingest_once()
            if n:
                print(f"[ingestor] Inserciones nuevas: {n}")
        except Exception as e:
            print(f"[ingestor] Error de ciclo: {e}")
        time.sleep(POLL_SECONDS)

def start_background_thread():
    t = threading.Thread(target=run_ingestor_forever, daemon=True)
    t.start()
    return t
