# app/main.py
from flask import Flask, jsonify
from .config import Config
from .utils import get_thingspeak_data, validate_data, get_thingspeak_feeds, parse_feed_to_sensor_dict
from .db import init_db, guardar_lectura
from .analysis import AnalysisConfig, compute_tds_baseline, analizar_directo, analizar_indirecto
from .database import SessionLocal
from .ingestor import start_background_thread

app = Flask(__name__)
app.config.from_object(Config)
init_db(app)

if not app.debug or os.environ.get("WERKZEUG_RUN_MAIN") == "true":
    start_background_thread()

@app.route('/')
def index():
    return "Backend en funcionamiento!"

@app.route('/get-data', methods=['GET'])   # 👈 quitamos los @@
def get_data():
    feeds = get_thingspeak_feeds(20)
    if not feeds:
        return jsonify({"error": "No data from ThingSpeak"}), 404

    latest_raw = feeds[-1]
    data = parse_feed_to_sensor_dict(latest_raw)

    valid, errors = validate_data({
        "distance": data["distance"],
        "temperature": data["temperature"],
        "ph": data["ph"],
        "conductivity": data["conductivity"],
        "r": data["r"], "g": data["g"], "b": data["b"]
    })
    if not valid:
        return jsonify({"error": "Datos no válidos", "details": errors}), 400

    cfg = AnalysisConfig()
    tds_base, n_used = compute_tds_baseline(feeds, cfg.TDS_BASE_DEFAULT)
    directo = analizar_directo(data)
    indirecto = analizar_indirecto(data, cfg, tds_base, n_used)

    db = SessionLocal()
    try:
        guardar_lectura(db, data, directo, indirecto)
    except Exception as e:
        db.rollback()
        print(f"Error al guardar en SQL: {e}")
    finally:
        db.close()

    return jsonify({
        "data_original": data,
        "analisis_directo": directo,
        "analisis_indirecto": indirecto
    })

if __name__ == "__main__":
    # Ejecutando como script (no como paquete):
    app.run(debug=True)
