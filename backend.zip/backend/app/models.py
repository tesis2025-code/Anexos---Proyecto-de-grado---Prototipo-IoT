# app/models.py
from sqlalchemy import Column, Integer, Float, String, DateTime, Boolean
from datetime import datetime
from .database import Base

class Lectura(Base):
    __tablename__ = "lecturas"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(64), default="TTGO-01", index=True)
    fecha_hora = Column(DateTime, default=datetime.utcnow)

    # Datos originales
    distance = Column(Float)
    temperature = Column(Float)
    ph = Column(Float)
    tds = Column(Float)
    conductivity = Column(Float)
    r = Column(Integer)
    g = Column(Integer)
    b = Column(Integer)

    # Análisis directo
    temperatura_ok = Column(Boolean)
    ph_ok = Column(Boolean)
    conductividad_ok = Column(Boolean)
    leche_calidad = Column(String(16))

    # Análisis indirecto
    volumen_L = Column(Float)
    densidad_est = Column(Float)
    solidos_totales_est_pct = Column(Float)
    grasa_est_pct = Column(Float)
    adulteracion_sospechosa = Column(Boolean)

    ts_entry_id = Column(Integer, index=True)  
