import requests
from urllib.parse import urlencode
from .config import Config

def get_thingspeak_data():
    """
    Hace una solicitud GET a la API de ThingSpeak para obtener los datos más recientes.
    """
    try:
        # Hacer la solicitud GET a ThingSpeak
        response = requests.get(Config.THINGSPEAK_URL)
        
        # Verificar si la solicitud fue exitosa (código 200)
        if response.status_code == 200:
            # Convertir la respuesta JSON en un diccionario
            data = response.json()

            # Imprimir toda la estructura de los datos recibidos para depuración
            print("Datos completos recibidos desde ThingSpeak:", data)

            # Acceder a los feeds (las mediciones)
            feeds = data.get('feeds', [])

            # Si hay datos, obtener la última lectura
            if feeds:
                latest_feed = feeds[-1]  # Obtener la última lectura
                # Mapear los campos a las variables correspondientes
                distance = latest_feed.get('field1', None)
                temperature = latest_feed.get('field2', None)
                ph = latest_feed.get('field3', None)
                tds = latest_feed.get('field4', None)
                conductivity = latest_feed.get('field5', None)
                r = latest_feed.get('field6', None)
                g = latest_feed.get('field7', None)
                b = latest_feed.get('field8', None)

                # Empaquetamos los datos para validación
                sensor_data = {
                    "distance": distance,
                    "temperature": temperature,
                    "ph": ph,
                    "tds": tds,
                    "conductivity": conductivity,
                    "r": r,
                    "g": g,
                    "b": b
                }

                # Validar los datos
                valid, errors = validate_data(sensor_data)
                if valid:
                    return sensor_data  # Si los datos son válidos, los retornamos
                else:
                    print(f"Datos no válidos: {errors}")
                    return None  # Si los datos no son válidos, retornamos None
            else:
                return None  # No hay datos
        else:
            print(f"Error en la solicitud a ThingSpeak: {response.status_code}")
            return None
    except Exception as e:
        print(f"Error al obtener los datos de ThingSpeak: {str(e)}")
        return None


def validate_data(data):
    """
    Valida los datos recibidos de ThingSpeak y verifica si están dentro de los rangos definidos.
    """
    valid = True
    errors = [] 

    # Validación de distancia (entre 0 y 46.5 cm)
    if data['distance'] is not None and not (0 <= float(data['distance']) <= 46.5):
        valid = False
        errors.append(f"Distancia fuera de rango: {data['distance']} cm")
    
    # Validación de temperatura (entre 0ºC y 10ºC)
    if data['temperature'] is not None and not (0 <= float(data['temperature']) <= 10):
        valid = False
        errors.append(f"Temperatura fuera de rango: {data['temperature']}°C")
    
    # Validación de pH (entre 6.0 y 7.2)
    if data['ph'] is not None and not (4 <= float(data['ph']) <= 7.2):
        valid = False
        errors.append(f"pH fuera de rango: {data['ph']}")
    
    # Validación de conductividad (entre 0 y 8000 µS/cm)
    if data['conductivity'] is not None and not (0 <= float(data['conductivity']) <= 8000):
        valid = False
        errors.append(f"Conductividad fuera de rango: {data['conductivity']} µS/cm")
    
    # Validación de color (debe ser un valor entre 0 y 255)
    if data['r'] is not None and not (0 <= int(data['r']) <= 255):
        valid = False
        errors.append(f"Color R fuera de rango: {data['r']}")
    if data['g'] is not None and not (0 <= int(data['g']) <= 255):
        valid = False
        errors.append(f"Color G fuera de rango: {data['g']}")
    if data['b'] is not None and not (0 <= int(data['b']) <= 255):
        valid = False
        errors.append(f"Color B fuera de rango: {data['b']}")

    return valid, errors

def _with_results_param(base_url: str, n: int) -> str:
    # Si ya trae ?... añadimos &results, si no, agregamos ?results
    sep = '&' if '?' in base_url else '?'
    return f"{base_url}{sep}{urlencode({'results': n})}"

def get_thingspeak_feeds(n: int):
    """Devuelve la lista de feeds cruda (JSON ThingSpeak) con n lecturas."""
    url = _with_results_param(Config.THINGSPEAK_URL, n)
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    payload = r.json()
    return payload.get("feeds", []) or []

def parse_feed_to_sensor_dict(feed: dict) -> dict:
    """Mapea un feed de ThingSpeak a nuestro esquema de claves + timestamp."""
    return {
        "entry_id":     feed.get("entry_id"),
        "distance":     feed.get("field1"),
        "temperature":  feed.get("field2"),
        "ph":           feed.get("field3"),
        "tds":          feed.get("field4"),
        "conductivity": feed.get("field5"),
        "r":            feed.get("field6"),
        "g":            feed.get("field7"),
        "b":            feed.get("field8"),
        "timestamp":    feed.get("created_at"),
    }